from django.apps import AppConfig


class CounterConfig(AppConfig):
    name = 'counter'
